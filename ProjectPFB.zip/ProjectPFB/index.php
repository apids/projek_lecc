<?php
require_once __DIR__ . '/session.php';
$pageTitle = 'StepVer - Temukan Event Lari Terbaik';

// Ambil jumlah event aktual per kategori dari DB
$host = "127.0.0.1";
$db_user = "root";
$db_pass = "";
$db_name = "projectlec";

$countRoad = $countTri = $countTrail = 0;
$conn = @mysqli_connect($host, $db_user, $db_pass, $db_name);
if ($conn) {
    $q = function($table) use ($conn) {
        $res = $conn->query("SELECT COUNT(*) AS c FROM {$table}");
        if ($res && ($row = $res->fetch_assoc())) return (int)$row['c'];
        return 0;
    };
    $countRoad = $q('road_run');
    $countTri = $q('triathlons');
    $countTrail = $q('trail_run');
}

// Ambil masing-masing 1 event mendatang per kategori
$featuredEvents = [];
if ($conn) {
    $fetchOne = function($table, $label) use ($conn) {
        // Urutkan berdasarkan tanggal jika ada
        $res = $conn->query("SELECT * FROM {$table} ORDER BY event_date ASC LIMIT 1");
        if ($res && ($row = $res->fetch_assoc())) {
            return [
                'id' => $row['id'] ?? null,
                'title' => $row['event_name'] ?? ($row['title'] ?? ($row['name'] ?? 'Event')),
                'date' => $row['event_date'] ?? ($row['date'] ?? '-'),
                'location' => $row['location'] ?? ($row['event_location'] ?? '-'),
                'fee' => $row['registration_fee'] ?? ($row['price'] ?? '-'),
                'category' => $label
            ];
        }
        return null;
    };

    if ($ev = $fetchOne('road_run', 'Road Run')) {
        $featuredEvents[] = $ev;
    }
    if ($ev = $fetchOne('triathlons', 'Triathlon')) {
        $featuredEvents[] = $ev;
    }
    if ($ev = $fetchOne('trail_run', 'Trail Run')) {
        $featuredEvents[] = $ev;
    }

    $conn->close();
}
?>
<!doctype html>
<html lang="id">
<?php include __DIR__ . '/includes/head.php'; ?>
<body class="home-page">
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="home-content">
    <section class="hero-section">
        <div class="category-container">
            <a href="category.php?event_type=Road%20Run" class="category-link">
                <div class="category-card">
                    <div class="category-image" style="background-image:url('ASSET/marathon.jpg')"></div>
                    <div class="category-overlay">
                        <h3>Road Run</h3>
                        <p><?= number_format($countRoad) ?> acara</p>
                    </div>
                </div>
            </a>

            <a href="category.php?event_type=Triathlon" class="category-link">
                <div class="category-card">
                    <div class="category-image" style="background-image:url('ASSET/triathlon.jpg')"></div>
                    <div class="category-overlay">
                        <h3>Triathlon</h3>
                        <p><?= number_format($countTri) ?> acara</p>
                    </div>
                </div>
            </a>

            <a href="category.php?event_type=Trail%20Run" class="category-link">
                <div class="category-card">
                    <div class="category-image" style="background-image:url('ASSET/trailrun.jpg')"></div>
                    <div class="category-overlay">
                        <h3>Trail Run</h3>
                        <p><?= number_format($countTrail) ?> acara</p>
                    </div>
                </div>
            </a>
        </div>
    </section>

    <section class="events-list-section">
        <h2>Event Lari Mendatang</h2>
        <div class="events-grid">
            <?php if (empty($featuredEvents)): ?>
                <p>Tidak ada event tersedia saat ini.</p>
            <?php else: ?>
                <?php foreach ($featuredEvents as $e): ?>
                    <div class="event-card">
                        <h3><?= htmlspecialchars($e['title']) ?></h3>
                        <div class="event-meta">
                            <div class="meta-row">🏷 <span><?= htmlspecialchars($e['category']) ?></span></div>
                            <div class="meta-row">📅 <span><?= htmlspecialchars($e['date']) ?></span></div>
                            <div class="meta-row">📍 <span><?= htmlspecialchars($e['location']) ?></span></div>
                            <div class="meta-row">💰 <span><?= htmlspecialchars($e['fee']) ?></span></div>
                        </div>
                        <?php
                        $detailHref = 'event-detail.php?id=' . urlencode(base64_encode($e['title']));
                        if (!empty($e['id'])) {
                            $detailHref = 'event-detail.php?event_id=' . urlencode($e['id']);
                        }
                        ?>
                        <a href="<?= htmlspecialchars($detailHref) ?>" class="btn-detail btn">Lihat Detail</a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="view-all-cta" style="text-align:center;margin-top:24px;">
            <a href="all-events.php" class="btn-secondary btn">Lihat Semua Event</a>
        </div>
    </section>

    <section class="continent-section">
        <div class="continent-header">
            <h2>Acara Berdasarkan Lokasi</h2>
        </div>

        <div class="continent-container">
            <a href="location.php?loc=indonesia" class="continent-link">
                <div class="continent-card">
                    <div class="continent-image" style="background-image:url('ASSET/indo.jpg')"></div>
                    <h3>Indonesia</h3>
                    <p>35,914 acara</p>
                </div>
            </a>

            <a href="location.php?loc=international" class="continent-link">
                <div class="continent-card">
                    <div class="continent-image" style="background-image:url('ASSET/nyc.jpg')"></div>
                    <h3>International</h3>
                    <p>12,070 acara</p>
                </div>
            </a>
        </div>
    </section>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
<?php include __DIR__ . '/includes/footer-scripts.php'; ?>
</body>
</html>