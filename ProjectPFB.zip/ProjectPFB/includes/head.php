<?php
if (!isset($pageTitle) || empty($pageTitle)) { $pageTitle = 'StepVer'; }
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link rel="stylesheet" href="style.css">
</head>