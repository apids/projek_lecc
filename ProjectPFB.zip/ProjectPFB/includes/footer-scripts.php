<?php
// includes/footer-scripts.php
?>
<!-- common modals / scripts -->
<script src="script.js"></script>