<?php
// session must be started by caller (require_once 'session.php')
$isLoggedIn = isset($_SESSION['user_id']);
?>
<header class="header-home">
    <div class="navbar-container">
        <div class="navbar-left">
            <a href="index.php" class="logo-home">StepVer</a>
        </div>
        <nav class="navbar-center">
            <a href="category.php?cat=berlari" class="nav-item">Berlari</a>
            <a href="#" class="nav-item">Bersepeda</a>
            <a href="#" class="nav-item">Multisport</a>
            <a href="#" class="nav-item">Olahraga air</a>
            <a href="#" class="nav-item">Lainnya</a>
        </nav>
        <div class="navbar-right">
            <?php if ($isLoggedIn): ?>
                <div class="profile-wrapper">
                    <button class="profile-btn"><div class="profile-avatar">👤</div></button>
                    <div class="profile-dropdown">
                        <a href="profile.php" class="dropdown-item"><span>📝</span> Edit Profile</a>
                        <a href="logout.php" class="dropdown-item logout-item"><span>🚪</span> Sign Out</a>
                    </div>
                </div>
            <?php else: ?>
                <a href="login.php" class="btn-navbar-login">Masuk</a>
                <a href="regist.php" class="btn-navbar-register">Daftar</a>
            <?php endif; ?>
        </div>
    </div>
</header>