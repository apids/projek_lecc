<?php
// includes/footer.php
?>
<footer class="footer">
    <p>&copy; 2025, StepVer.</p>
</footer>