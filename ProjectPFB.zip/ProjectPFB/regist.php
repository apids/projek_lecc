<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="form-page"> 
    <header class="header">
        <div class="logo">
            "StepVer"
        </div>
    </header>

    <main class="main-content">
        <div class="split-container">
            <div class="left-panel">
                <div class="illustration-placeholder"></div>
                <h3>Daftar Event Lari Dengan Mudah Hanya di "StepVer"</h3>
                <p>Ayo Gabung Sekarang!</p>
            </div>

            <div class="right-panel">
                <div class="register-box">
                    <h4>Daftar Sekarang</h4>
                    <form id="registerForm" action="proses_registrasi.php" method="POST">
                        <div id="error-message" style="color: red; margin-bottom: 15px;"></div>

                        <label for="nama_lengkap" class="input-label">Nama Lengkap</label>
                        <input type="text" id="nama_lengkap" name="nama_lengkap" placeholder="Nama Lengkap" class="input-field" required>
                        <label for="email" class="input-label">E-mail</label>
                        <input type="email" id="email" name="email" placeholder="Contoh: nama@email.com" class="input-field" required>
                        <label for="password" class="input-label">Password</label>
                        <input type="password" id="password" name="password" placeholder="Password" class="input-field" required>
                        <label for="confirm_password" class="input-label">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" class="input-field" required>

                        <button type="submit" id="submitBtn" class="btn btn-register">Daftar</button>
                        <p class="login-prompt">Sudah memiliki akun? <a href="login.php" class="link-masuk">Log In</a></p>
                        <p class="terms-text">
                            Dengan mendaftar, saya menyetujui
                            <a href="#">Syarat & Ketentuan</a> serta <a href="#">Kebijakan Privasi "StepVer"</a>.
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <div id="success-modal" class="modal">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <h2>✅ Registrasi Berhasil!</h2>
            <p>Akun Anda telah berhasil dibuat. Anda akan diarahkan ke halaman Login dalam <span id="countdown">5</span> detik.</p>
            <button onclick="window.location.href='login.php'" class="modal-button">Masuk Sekarang</button>
        </div>
    </div>

    <footer class="footer">
        <p>© 2025, StepVer</p>
        <p>|</p>
        <a href="#" class="tokopedia-care">StepVer</a>
    </footer>

    <script src="script.js"></script>

    
</body>
</html>