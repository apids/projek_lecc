<?php
require_once __DIR__ . '/session.php';

// Ambil parameter event_type (fallback ke "cat" agar kompatibel dengan tautan lama)
$rawType = $_GET['event_type'] ?? $_GET['cat'] ?? '';
$eventType = trim(filter_var($rawType, FILTER_SANITIZE_FULL_SPECIAL_CHARS));

// Ambil filter jarak
$allowedDistances = ['5k', '10k', 'half marathon', 'full marathon', 'ultra'];
$rawDistance = strtolower(trim($_GET['distance'] ?? ''));
$distanceFilter = in_array($rawDistance, $allowedDistances, true) ? $rawDistance : '';

// Filter lokasi (Indonesia / International)
$allowedLocations = ['indonesia', 'international'];
$rawLoc = strtolower(trim($_GET['loc'] ?? ''));
$locationFilter = in_array($rawLoc, $allowedLocations, true) ? $rawLoc : '';

if ($eventType === '') {
    header("Location: index.php");
    exit;
}

// Untuk Triathlon hanya sediakan filter lokasi (abaikan filter jarak)
if (strcasecmp($eventType, 'triathlon') === 0) {
    $distanceFilter = '';
}

$pageTitle = 'Kategori - ' . $eventType;

// Konfigurasi koneksi database
$host = "127.0.0.1";
$db_user = "root";
$db_pass = "";
$db_name = "projectlec";

$events = [];
$dbError = '';

// Ambil data event berdasarkan event_type
$conn = @mysqli_connect($host, $db_user, $db_pass, $db_name);
if ($conn) {
    // Jika Road Run, gunakan tabel road_run (tanpa kolom event_type)
    if (strcasecmp($eventType, 'road run') === 0) {
        $sql = "SELECT * FROM road_run";
        $result = $conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $events[] = [
                    'id' => $row['id'] ?? null,
                    'name' => $row['event_name'] ?? ($row['title'] ?? ($row['name'] ?? 'Event Tanpa Nama')),
                    'date' => $row['event_date'] ?? ($row['date'] ?? '-'),
                    'location' => $row['location'] ?? ($row['event_location'] ?? '-'),
                    'distance' => $row['distance'] ?? ($row['category'] ?? '-'),
                    'fee' => $row['registration_fee'] ?? ($row['price'] ?? '-'),
                    'type' => 'Road Run',
                    'country' => $row['country'] ?? ($row['nation'] ?? ''),
                ];
            }
        } else {
            $dbError = 'Gagal mengambil data Road Run.';
        }
    } elseif (strcasecmp($eventType, 'triathlon') === 0) {
        $sql = "SELECT * FROM triathlons";
        $result = $conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $events[] = [
                    'id' => $row['id'] ?? null,
                    'name' => $row['event_name'] ?? ($row['title'] ?? ($row['name'] ?? 'Event Tanpa Nama')),
                    'date' => $row['event_date'] ?? ($row['date'] ?? '-'),
                    'location' => $row['location'] ?? ($row['event_location'] ?? '-'),
                    'distance' => $row['distance'] ?? ($row['category'] ?? '-'),
                    'fee' => $row['registration_fee'] ?? ($row['price'] ?? '-'),
                    'type' => 'Triathlon',
                    'country' => $row['country'] ?? ($row['nation'] ?? ''),
                ];
            }
        } else {
            $dbError = 'Gagal mengambil data Triathlon.';
        }
    } elseif (strcasecmp($eventType, 'trail run') === 0 || strcasecmp($eventType, 'trailrun') === 0) {
        $sql = "SELECT * FROM trail_run";
        $result = $conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $events[] = [
                    'id' => $row['id'] ?? null,
                    'name' => $row['event_name'] ?? ($row['title'] ?? ($row['name'] ?? 'Event Tanpa Nama')),
                    'date' => $row['event_date'] ?? ($row['date'] ?? '-'),
                    'location' => $row['location'] ?? ($row['event_location'] ?? '-'),
                    'distance' => $row['distance'] ?? ($row['category'] ?? '-'),
                    'fee' => $row['registration_fee'] ?? ($row['price'] ?? '-'),
                    'type' => 'Trail Run',
                    'country' => $row['country'] ?? ($row['nation'] ?? ''),
                ];
            }
        } else {
            $dbError = 'Gagal mengambil data Trail Run.';
        }
    } else {
        // Jika event_type tidak dikenal, kosongkan hasil
        $events = [];
    }
    $conn->close();
} else {
    $dbError = 'Koneksi database gagal.';
}

// Helper: konversi teks jarak ke angka kilometer (perkiraan)
function normalizeDistanceKm($value) {
    $val = strtolower(trim((string)$value));
    if ($val === '') return null;

    // Kata kunci khusus
    if (strpos($val, 'half marathon') !== false) {
        return 21.1; // Half Marathon
    }
    if (strpos($val, 'full marathon') !== false) {
        return 42.2; // Full Marathon
    }
    // Jika hanya "marathon" tanpa prefix, asumsi full
    if ($val === 'marathon' || $val === 'full marathon') {
        return 42.2;
    }

    // Ambil angka sebelum huruf k
    if (preg_match('/([\d\.]+)\s*k/', $val, $m)) {
        return (float)$m[1];
    }

    // Ambil angka apa pun sebagai km
    if (preg_match('/([\d\.]+)/', $val, $m)) {
        return (float)$m[1];
    }

    return null;
}

// Terapkan filter jarak jika dipilih (numerik)
if ($distanceFilter !== '') {
    $events = array_values(array_filter($events, function ($e) use ($distanceFilter) {
        $distText = $e['distance'];
        $km = normalizeDistanceKm($distText);

        // Jika gagal parsing, fallback ke pencarian kata kunci lama
        if ($km === null) {
            $dist = strtolower($distText);
            return strpos($dist, $distanceFilter) !== false;
        }

        switch ($distanceFilter) {
            case '5k':
                return abs($km - 5) < 0.6; // toleransi ±0.6 km
            case '10k':
                return abs($km - 10) < 0.8;
            case 'half marathon':
                return $km >= 20 && $km <= 22.5;
            case 'full marathon':
                return $km >= 41 && $km <= 43.5;
            case 'ultra':
                return $km > 42;
            default:
                return true;
        }
    }));
}

// Terapkan filter lokasi jika dipilih
if ($locationFilter !== '') {
    $indoKeywords = ['indonesia','jakarta','bandung','bali','probolinggo','lombok'];
    $events = array_values(array_filter($events, function ($e) use ($locationFilter, $indoKeywords) {
        $loc = strtolower($e['location']);
        $country = strtolower($e['country'] ?? '');

        // Prioritaskan kolom country jika tersedia
        if ($country !== '') {
            $isIndo = $country === 'indonesia' || $country === 'id';
        } else {
            $isIndo = false;
            foreach ($indoKeywords as $kw) {
                if (strpos($loc, $kw) !== false) {
                    $isIndo = true;
                    break;
                }
            }
        }

        return $locationFilter === 'indonesia' ? $isIndo : !$isIndo;
    }));
}
?>
<!doctype html>
<html lang="id">
<?php include __DIR__ . '/includes/head.php'; ?>
<body class="home-page">
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="category-page-main">
    <div class="category-layout">
        <aside class="filter-card">
            <h3 class="filter-title">Filter</h3>
            <form method="get" class="filter-form">
                <input type="hidden" name="event_type" value="<?= htmlspecialchars($eventType) ?>">

                <?php if (strcasecmp($eventType, 'triathlon') !== 0): ?>
                <div class="filter-block">
                    <p class="filter-subtitle">Jarak</p>
                    <label class="filter-radio">
                        <input type="radio" name="distance" value="" <?= $distanceFilter === '' ? 'checked' : '' ?>> Semua
                    </label>
                    <label class="filter-radio">
                        <input type="radio" name="distance" value="5k" <?= $distanceFilter === '5k' ? 'checked' : '' ?>> 5K
                    </label>
                    <label class="filter-radio">
                        <input type="radio" name="distance" value="10k" <?= $distanceFilter === '10k' ? 'checked' : '' ?>> 10K
                    </label>
                    <label class="filter-radio">
                        <input type="radio" name="distance" value="half marathon" <?= $distanceFilter === 'half marathon' ? 'checked' : '' ?>> Half Marathon
                    </label>
                    <label class="filter-radio">
                        <input type="radio" name="distance" value="full marathon" <?= $distanceFilter === 'full marathon' ? 'checked' : '' ?>> Full Marathon
                    </label>
                    <label class="filter-radio">
                        <input type="radio" name="distance" value="ultra" <?= $distanceFilter === 'ultra' ? 'checked' : '' ?>> Ultra
                    </label>
                </div>
                <?php endif; ?>

                <div class="filter-block">
                    <p class="filter-subtitle">Lokasi</p>
                    <label class="filter-radio">
                        <input type="radio" name="loc" value="" <?= $locationFilter === '' ? 'checked' : '' ?>> Semua
                    </label>
                    <label class="filter-radio">
                        <input type="radio" name="loc" value="indonesia" <?= $locationFilter === 'indonesia' ? 'checked' : '' ?>> Indonesia
                    </label>
                    <label class="filter-radio">
                        <input type="radio" name="loc" value="international" <?= $locationFilter === 'international' ? 'checked' : '' ?>> International
                    </label>
                </div>

                <button type="submit" class="btn btn-detail filter-apply">Terapkan</button>
            </form>
        </aside>

        <div class="category-content">
            <h2 class="category-title">Event: <?= htmlspecialchars($eventType) ?></h2>

            <?php if ($dbError): ?>
                <div class="error-message" style="margin:16px 0; color:#b00020; background:#fde6e8; padding:12px 16px; border-radius:8px;">
                    <?= htmlspecialchars($dbError) ?>
                </div>
            <?php endif; ?>

            <div class="events-grid" style="margin-top:20px;">
                <?php if (count($events) === 0): ?>
                    <p>Tidak ada event untuk filter ini.</p>
                <?php else: ?>
                    <?php foreach ($events as $e): ?>
                        <div class="event-card">
                            <h3><?= htmlspecialchars($e['name']) ?></h3>
                            <div class="event-meta">
                                <div class="meta-row">📅 <span><?= htmlspecialchars($e['date']) ?></span></div>
                                <div class="meta-row">📍 <span><?= htmlspecialchars($e['location']) ?></span></div>
                                <div class="meta-row">💰 <span><?= htmlspecialchars($e['fee'] ?? '-') ?></span></div>
                            </div>
                            <?php
                            $detailHref = 'event-detail.php?id=' . urlencode(base64_encode($e['name']));
                            if (!empty($e['id'])) {
                                // Gunakan event_id jika tersedia untuk lookup DB yang lebih presisi
                                $detailHref = 'event-detail.php?event_id=' . urlencode($e['id']);
                            }
                            ?>
                            <a href="<?= htmlspecialchars($detailHref) ?>" class="btn-detail btn">Lihat Detail</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div style="text-align:center;margin-top:24px;">
                <a href="index.php" class="btn-secondary btn">Kembali ke Beranda</a>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
<?php include __DIR__ . '/includes/footer-scripts.php'; ?>
</body>
</html>