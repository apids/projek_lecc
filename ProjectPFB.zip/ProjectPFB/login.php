<?php
ob_start();
session_start();

// 1. Konfigurasi Koneksi Database (sama seperti di proses_registrasi.php)
$host = "127.0.0.1";
$username = "root";
$password = "";
$databasename = "projectlec";

// 2. Buat koneksi
$conn = mysqli_connect($host, $username, $password, $databasename);

// 3. Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$error_message = '';

// 4. Proses Login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, trim($_POST['email_phone'] ?? ''));
    $password = trim($_POST['password'] ?? '');

    // Validasi input tidak kosong
    if (empty($email) || empty($password)) {
        $error_message = "Email dan password harus diisi.";
    } else {
        // Query ke database untuk cari user berdasarkan email
        $query = "SELECT id, nama_lengkap, email, password FROM users WHERE email = ?";
        
        // Persiapan statement
        $stmt = $conn->prepare($query);
        
        if (!$stmt) {
            $error_message = "Terjadi kesalahan sistem. Silakan coba lagi.";
        } else {
            // Binding parameter
            $stmt->bind_param("s", $email);
            
            // Eksekusi
            $stmt->execute();
            
            // Ambil hasilnya
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                
                // Verifikasi password menggunakan password_verify
                if (password_verify($password, $user['password'])) {
                    // Password benar, simpan session
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_name'] = $user['nama_lengkap'];
                    $_SESSION['login_time'] = time();
                    
                    // Redirect ke halaman index
                    header("Location: index.php");
                    ob_end_flush();
                    exit();
                } else {
                    // Password salah
                    $error_message = "Password yang Anda masukkan salah.";
                }
            } else {
                // Email tidak ditemukan
                $error_message = "Email tidak ditemukan. Silakan daftar terlebih dahulu.";
            }
            
            $stmt->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>log In</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="form-page">
    <header class="header">
        <div class="logo">
            "StepVer"
        </div>
    </header>

    <main class="main-content">
        <div class="split-container">
            <div class="left-panel">
                <div class="illustration-placeholder"></div>
                <h3>Daftar Event Lari Dengan Mudah Hanya di "StepVer"</h3>
                <p>Ayo Gabung Sekarang!</p>
            </div>

            <div class="right-panel">
                <div class="login-box">
                    <h4>Log In</h4>
                    
                    <?php if ($error_message): ?>
                        <div class="error-message">
                            <span class="error-icon">⚠️</span>
                            <p><?php echo htmlspecialchars($error_message); ?></p>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <label for="email_phone" class="input-label">E-mail</label>
                        <input type="email" id="email_phone" name="email_phone" placeholder="Contoh: nama@example.com" class="input-field" value="<?php echo htmlspecialchars($_POST['email_phone'] ?? ''); ?>" required>
                        
                        <label for="password" class="input-label">Password</label>
                        <input type="password" id="password" name="password" placeholder="Password" class="input-field" required>

                        <button type="submit" class="btn btn-register">Masuk</button>
                        
                        <p class="login-prompt">Belum memiliki akun? <a href="regist.php" class="link-masuk">Register</a></p>
                        
                        <p class="terms-text">
                            Dengan mendaftar, saya menyetujui
                            <a href="">Syarat & Ketentuan</a> serta <a href="#">Kebijakan Privasi "StepVer"</a>.
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer">
        <p>© 2025, StepVer</p>
        <p>|</p>
        <a href="#" class="tokopedia-care">StepVer</a>
    </footer>
</body>
</html>