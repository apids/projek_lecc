<?php
// 1. Konfigurasi Koneksi Database
$host = "127.0.0.1";
$username = "root";
$password = "";
$databasename = "projectlec";

// 2. Buat koneksi (PROSEDURAL)
$conn = mysqli_connect($host, $username, $password, $databasename);

// 3. Cek koneksi
if (!$conn) {
    // Tampilkan pesan error spesifik menggunakan fungsi prosedural
    die("Koneksi gagal: " . mysqli_connect_error());
}

// 4. Validasi Data Sisi Server
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari POST dan sanitasi
    $nama_lengkap = mysqli_real_escape_string($conn, trim($_POST['nama_lengkap']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validasi Dasar
    if (empty($nama_lengkap) || empty($email) || empty($password) || empty($confirm_password)) {
        die("Error: Semua field wajib diisi.");
    }
    
    // Validasi Kesamaan Password
    if ($password !== $confirm_password) {
        die("Error: Konfirmasi password tidak cocok.");
    }
    
    // Validasi Format Email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Error: Format email tidak valid.");
    }

    // 5. Cek apakah Email sudah terdaftar (Penting!)
    $check_sql = "SELECT email FROM users WHERE email = ?";
    
    // Persiapan statement
    $stmt = $conn->prepare($check_sql);
    
    // Binding parameter
    $stmt->bind_param("s", $email); // "s" untuk string
    
    // Eksekusi
    $stmt->execute();
    
    // Ambil hasilnya
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Jika jumlah baris > 0, email sudah terdaftar
        $stmt->close();
        
        // Arahkan kembali ke halaman registrasi dengan parameter error
        header("Location: regist.php?register=error&type=duplicate");
        exit();
    }
    
    $stmt->close();
    // 6. Hashing Password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // 7. Query Insert Data ke Database
    $sql = "INSERT INTO users (nama_lengkap, email, password) VALUES ('$nama_lengkap', '$email', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        // Ganti redirect langsung ke login.php
        // Ubah: header("Location: login.php?status=success");
        // Menjadi: Redirect kembali ke halaman registrasi dengan parameter sukses
        header("Location: regist.php?register=success");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>