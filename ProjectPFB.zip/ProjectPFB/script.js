
    document.getElementById('registerForm').addEventListener('submit', function(event) {

        // Ambil nilai input
        const namaLengkap = document.getElementById('nama_lengkap').value.trim();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        const errorDiv = document.getElementById('error-message');
        
        let errorMessage = '';

        // 1. Validasi Input Kosong (seharusnya sudah dihandle 'required', tapi ini untuk pencegahan)
        if (namaLengkap === '' || email === '' || password === '' || confirmPassword === '') {
            errorMessage = 'Semua field wajib diisi.';
        }
        
        // 2. Validasi Password Minimal 6 Karakter
        else if (password.length < 6) {
            errorMessage = 'Password minimal harus 6 karakter.';
        }
        
        // 3. Validasi Kesamaan Password
        else if (password !== confirmPassword) {
            errorMessage = 'Konfirmasi Password tidak cocok.';
        }
        
        // 4. Validasi Format Email Sederhana (opsional, PHP akan melakukan yang lebih ketat)
        else if (!isValidEmail(email)) {
            errorMessage = 'Format Email tidak valid.';
        }
        
        // Fungsi sederhana untuk validasi format email
        function isValidEmail(email) {
            const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(String(email).toLowerCase());
        }

        // Tampilkan error jika ada
        if (errorMessage) {
            event.preventDefault(); // Mencegah formulir dikirim
            errorDiv.textContent = errorMessage;
        } else {
            errorDiv.textContent = ''; // Bersihkan pesan error jika valid
            // Formulir akan dikirim ke 'proses_registrasi.php'
        }
    });


    function handleRegistrationSuccess() {
            const urlParams = new URLSearchParams(window.location.search);
            
            if (urlParams.get('register') === 'success') {
                const modal = document.getElementById('success-modal');
                const countdownSpan = document.getElementById('countdown');
                const closeButton = document.querySelector('.close-button');
                let time = 5 ;

                // Tampilkan Modal
                modal.style.display = 'block';

                // Fungsi untuk menghitung mundur
                const countdown = setInterval(() => {
                    time--;
                    countdownSpan.textContent = time;

                    if (time <= 0) {
                        clearInterval(countdown);
                        // Redirect otomatis setelah hitungan mundur selesai
                        window.location.href = 'login.php'; 
                    }
                }, 1000); // Hitungan mundur setiap 1 detik

                // Logika untuk menutup modal secara manual (optional)
                closeButton.onclick = function() {
                    clearInterval(countdown); // Hentikan hitungan mundur
                    modal.style.display = 'none';
                    window.location.href = 'login.php'; // Redirect saat ditutup
                }

                // Menutup modal jika user mengklik area di luar kotak
                window.onclick = function(event) {
                    if (event.target == modal) {
                        clearInterval(countdown);
                        modal.style.display = "none";
                        window.location.href = 'login.php';
                    }
                }
            }
        }

        // Pastikan kode dijalankan setelah semua elemen dimuat
        window.onload = handleRegistrationSuccess;

    // Di file script.js

    function handleRegistrationError() {
        const urlParams = new URLSearchParams(window.location.search);
        const errorMessageDiv = document.getElementById('error-message');

        // Cek jika ada error dan tipenya adalah duplicate
        if (urlParams.get('register') === 'error' && urlParams.get('type') === 'duplicate') {
            
            // Tampilkan pesan error
            errorMessageDiv.textContent = "❌ Registrasi Gagal: Email ini sudah digunakan. Silakan Log In.";
            
            // Opsional: Hapus parameter error dari URL agar tidak muncul lagi saat di-refresh
            // history.replaceState(null, '', location.pathname); 
        }
    }

    // Tambahkan panggilan fungsi ini di window.onload bersama handleRegistrationSuccess
    window.onload = function() {
        handleRegistrationSuccess(); // Menangani success modal
        handleRegistrationError();   // Menangani error duplikasi
    };