<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Koneksi DB (sama dengan file lain)
$host = "127.0.0.1";
$db_user = "root";
$db_pass = "";
$db_name = "projectlec";

$conn = mysqli_connect($host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$error_message = '';
$success_message = '';
$input_email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input_email = trim($_POST['email'] ?? '');
    $new_pass = $_POST['password'] ?? '';
    $confirm_pass = $_POST['confirm_password'] ?? '';

    // Validasi dasar
    if ($input_email === '' || $new_pass === '' || $confirm_pass === '') {
        $error_message = "Semua field wajib diisi.";
    } elseif (!filter_var($input_email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Format email tidak valid.";
    } else {
        // Cek apakah email terdaftar
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        if (!$check_stmt) {
            $error_message = "Terjadi kesalahan sistem.";
        } else {
            $check_stmt->bind_param("s", $input_email);
            $check_stmt->execute();
            $check_stmt->store_result();

            if ($check_stmt->num_rows === 0) {
                $error_message = "Email tidak terdaftar.";
            } else {
                // Email ada, cek kecocokan password
                if ($new_pass !== $confirm_pass) {
                    $error_message = "Password Berbeda";
                } else {
                    // Update password (hash terlebih dahulu)
                    $hashed = password_hash($new_pass, PASSWORD_DEFAULT);
                    $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
                    if (!$update_stmt) {
                        $error_message = "Terjadi kesalahan sistem saat memperbarui password.";
                    } else {
                        $update_stmt->bind_param("ss", $hashed, $input_email);
                        if ($update_stmt->execute()) {
                            $success_message = "Password berhasil diperbarui.";
                           // Tutup statement dan koneksi, lalu logout dan redirect ke halaman login
                           $update_stmt->close();
                            $conn->close();

                           // Hapus session dan logout
                           session_unset();
                            session_destroy();
                            
                           // Redirect ke halaman login
                           header("Location: login.php");
                           exit();
                     } else {
                         $error_message = "Gagal memperbarui password. Coba lagi.";
                     }
-                        $update_stmt->close();
                    }
                }
            }

            $check_stmt->close();
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="profile-page">
    <main class="profile-content">
        <div class="profile-container">
            <div class="profile-card">
                <h2>Edit Profile</h2>

                <?php if ($error_message): ?>
                    <div class="error-message">
                        <span class="error-icon">⚠️</span>
                        <p><?php echo htmlspecialchars($error_message); ?></p>
                    </div>
                <?php endif; ?>

                <?php if ($success_message): ?>
                    <div class="success-message">
                        <p><?php echo htmlspecialchars($success_message); ?></p>
                    </div>
                <?php endif; ?>

                <form class="profile-form" method="POST" novalidate>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Masukkan email" class="input-field" required value="<?php echo htmlspecialchars($input_email); ?>">
                    </div>

                    <div class="form-group">
                        <label for="password">New Password</label>
                        <input type="password" id="password" name="password" placeholder="Masukkan Password Baru" class="input-field" required>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password Baru" class="input-field" required>
                    </div>

                    <div>
                        <button type="submit" class="btn btn-register">Simpan Perubahan</button>
                        <button type="button" class="btn btn-cancel" onclick="window.location.href='index.php'">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <footer class="footer">
        <p>&copy; 2025, StepVer.</p>
    </footer>
</body>
</html>