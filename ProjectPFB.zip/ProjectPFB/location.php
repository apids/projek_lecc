<?php
require_once __DIR__ . '/session.php';

$raw = $_GET['loc'] ?? '';
$loc = strtolower(trim(filter_var($raw, FILTER_SANITIZE_FULL_SPECIAL_CHARS)));
if (!in_array($loc, ['indonesia','international'], true)) {
    header("Location: index.php");
    exit;
}

// DB config
$host = "127.0.0.1";
$db_user = "root";
$db_pass = "";
$db_name = "projectlec";

$conn = @mysqli_connect($host, $db_user, $db_pass, $db_name);
$events = [];
$dbError = '';

// Helper untuk ambil semua event dari tabel tertentu
$fetchAll = function($table, $categoryLabel) use ($conn, &$events) {
    $sql = "SELECT * FROM {$table}";
    $res = $conn->query($sql);
    if (!$res) {
        return "Gagal mengambil data dari {$table}.";
    }
    while ($row = $res->fetch_assoc()) {
        $events[] = [
            'id' => $row['id'] ?? null,
            'name' => $row['event_name'] ?? ($row['title'] ?? ($row['name'] ?? 'Event Tanpa Nama')),
            'date' => $row['event_date'] ?? ($row['date'] ?? '-'),
            'location' => $row['location'] ?? ($row['event_location'] ?? '-'),
            'distance' => $row['distance'] ?? ($row['category'] ?? '-'),
            'fee' => $row['registration_fee'] ?? ($row['price'] ?? '-'),
            'type' => $categoryLabel,
            'country' => strtolower($row['country'] ?? ($row['nation'] ?? '')),
        ];
    }
    return '';
};

if ($conn) {
    $err = $fetchAll('road_run', 'Road Run');
    if ($err) { $dbError = $err; }
    $err = $fetchAll('triathlons', 'Triathlon');
    if ($err && !$dbError) { $dbError = $err; }
    $err = $fetchAll('trail_run', 'Trail Run');
    if ($err && !$dbError) { $dbError = $err; }
    $conn->close();
} else {
    $dbError = 'Koneksi database gagal.';
}

// Filter lokasi
$indoKeywords = ['indonesia','jakarta','bandung','bali','probolinggo','lombok','surabaya','medan','makassar'];
$events = array_values(array_filter($events, function($e) use ($loc, $indoKeywords) {
    $country = strtolower($e['country'] ?? '');
    $city = strtolower($e['location']);
    $isIndo = false;
    if ($country !== '') {
        $isIndo = ($country === 'indonesia' || $country === 'id');
    } else {
        foreach ($indoKeywords as $kw) {
            if (strpos($city, $kw) !== false) {
                $isIndo = true;
                break;
            }
        }
    }
    return $loc === 'indonesia' ? $isIndo : !$isIndo;
}));

$pageTitle = 'Acara - ' . ucfirst($loc);
?>
<!doctype html>
<html lang="id">
<?php include __DIR__ . '/includes/head.php'; ?>
<body class="home-page">
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="category-page-main">
    <div class="category-layout">
        <div class="category-content" style="grid-column: 1 / -1;">
            <h2 class="category-title">Event berdasarkan Lokasi: <?= htmlspecialchars(ucfirst($loc)) ?></h2>

            <?php if ($dbError): ?>
                <div class="error-message" style="margin:16px 0; color:#b00020; background:#fde6e8; padding:12px 16px; border-radius:8px;">
                    <?= htmlspecialchars($dbError) ?>
                </div>
            <?php endif; ?>

            <div class="events-grid" style="margin-top:20px;">
                <?php if (count($events) === 0): ?>
                    <p>Tidak ada event untuk lokasi ini.</p>
                <?php else: ?>
                    <?php foreach ($events as $e): ?>
                        <div class="event-card">
                            <h3><?= htmlspecialchars($e['name']) ?></h3>
                            <div class="event-meta">
                                <div class="meta-row">📅 <span><?= htmlspecialchars($e['date']) ?></span></div>
                                <div class="meta-row">📍 <span><?= htmlspecialchars($e['location']) ?></span></div>
                                <div class="meta-row">💰 <span><?= htmlspecialchars($e['fee']) ?></span></div>
                            </div>
                            <?php
                            $detailHref = 'event-detail.php?id=' . urlencode(base64_encode($e['name']));
                            if (!empty($e['id'])) {
                                $detailHref = 'event-detail.php?event_id=' . urlencode($e['id']);
                            }
                            ?>
                            <a href="<?= htmlspecialchars($detailHref) ?>" class="btn-detail btn">Lihat Detail</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div style="text-align:center;margin-top:24px;">
                <a href="index.php" class="btn-secondary btn">Kembali ke Beranda</a>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
<?php include __DIR__ . '/includes/footer-scripts.php'; ?>
</body>
</html>