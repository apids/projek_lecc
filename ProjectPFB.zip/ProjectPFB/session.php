<?php
// Session initializer with 7-day fixed lifetime
$SESSION_LIFETIME = 7 * 24 * 60 * 60; // 7 days

session_set_cookie_params([
    'lifetime' => $SESSION_LIFETIME,
    'path' => '/',
    'domain' => '',
    'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Auto-logout after lifetime from login_time
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > $SESSION_LIFETIME)) {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    session_unset();
    session_destroy();
    // optional redirect is omitted to avoid header issues — pages can check and redirect if needed
}
?>