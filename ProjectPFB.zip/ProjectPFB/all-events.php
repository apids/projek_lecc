<?php
require_once __DIR__ . '/session.php';

// DB config
$host = "127.0.0.1";
$db_user = "root";
$db_pass = "";
$db_name = "projectlec";

$conn = @mysqli_connect($host, $db_user, $db_pass, $db_name);
$all = [];
$dbError = '';

$fetchAll = function($table, $categoryLabel) use ($conn, &$all) {
    $sql = "SELECT * FROM {$table}";
    $res = $conn->query($sql);
    if (!$res) {
        return "Gagal mengambil data dari {$table}.";
    }
    while ($row = $res->fetch_assoc()) {
        $all[] = [
            'id' => $row['id'] ?? null,
            'title' => $row['event_name'] ?? ($row['title'] ?? ($row['name'] ?? 'Event Tanpa Nama')),
            'date' => $row['event_date'] ?? ($row['date'] ?? '-'),
            'location' => $row['location'] ?? ($row['event_location'] ?? '-'),
            'fee' => $row['registration_fee'] ?? ($row['price'] ?? '-'),
            'category_title' => $categoryLabel,
        ];
    }
    return '';
};

if ($conn) {
    $err = $fetchAll('road_run', 'Road Run');
    if ($err) { $dbError = $err; }
    $err = $fetchAll('triathlons', 'Triathlon');
    if ($err && !$dbError) { $dbError = $err; }
    $err = $fetchAll('trail_run', 'Trail Run');
    if ($err && !$dbError) { $dbError = $err; }
    $conn->close();
} else {
    $dbError = 'Koneksi database gagal.';
}

$pageTitle = 'Semua Event';
?>
<!doctype html>
<html lang="id">
<?php include __DIR__ . '/includes/head.php'; ?>
<body class="home-page">
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="category-page-main">
    <div class="category-layout" style="grid-template-columns: 1fr;">
        <div class="category-content">
            <h2 class="category-title">Semua Event</h2>

            <?php if ($dbError): ?>
                <div class="error-message" style="margin:16px 0; color:#b00020; background:#fde6e8; padding:12px 16px; border-radius:8px;">
                    <?= htmlspecialchars($dbError) ?>
                </div>
            <?php endif; ?>

            <div class="events-grid" style="margin-top:20px;">
                <?php if (count($all) === 0): ?>
                    <p>Tidak ada event.</p>
                <?php else: ?>
                    <?php foreach ($all as $e): ?>
                        <div class="event-card">
                            <h3><?= htmlspecialchars($e['title']) ?></h3>
                            <div class="event-meta">
                                <div class="meta-row">🏷 <span><?= htmlspecialchars($e['category_title']) ?></span></div>
                                <div class="meta-row">📅 <span><?= htmlspecialchars($e['date']) ?></span></div>
                                <div class="meta-row">📍 <span><?= htmlspecialchars($e['location']) ?></span></div>
                                <div class="meta-row">💰 <span><?= htmlspecialchars($e['fee']) ?></span></div>
                            </div>
                            <?php
                            $detailHref = 'event-detail.php?id=' . urlencode(base64_encode($e['title']));
                            if (!empty($e['id'])) {
                                $detailHref = 'event-detail.php?event_id=' . urlencode($e['id']);
                            }
                            ?>
                            <a href="<?= htmlspecialchars($detailHref) ?>" class="btn-detail btn">Lihat Detail</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div style="text-align:center;margin-top:24px;">
                <a href="index.php" class="btn-secondary btn">Kembali ke Beranda</a>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
<?php include __DIR__ . '/includes/footer-scripts.php'; ?>
</body>
</html>