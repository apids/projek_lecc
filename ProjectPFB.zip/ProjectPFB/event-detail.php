<?php
require_once __DIR__ . '/session.php';

// --- Input parsing: event_id (prioritas) atau fallback id (base64 nama) ---
$rawId = $_GET['event_id'] ?? '';
$rawName = $_GET['id'] ?? '';
$eventId = ctype_digit((string)$rawId) ? (int)$rawId : null;
$eventNameParam = $rawName ? @base64_decode(urldecode($rawName)) : '';

// --- Koneksi database ---
$host = "127.0.0.1";
$db_user = "root";
$db_pass = "";
$db_name = "projectlec";

$conn = @mysqli_connect($host, $db_user, $db_pass, $db_name);
$event = null;
$eventSource = null; // 'road_run' atau 'events'
$dbError = '';

if ($conn) {
    // Helper untuk fetch dari tabel tertentu
    $fetchById = function($table, $id) use ($conn) {
        $stmt = $conn->prepare("SELECT * FROM {$table} WHERE id = ? LIMIT 1");
        if (!$stmt) return [null, 'Gagal menyiapkan query detail event.'];
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc() ?: null;
        $stmt->close();
        return [$row, ''];
    };

    $fetchByName = function($table, $name) use ($conn) {
        $stmt = $conn->prepare("SELECT * FROM {$table} WHERE event_name = ? LIMIT 1");
        if (!$stmt) return [null, 'Gagal menyiapkan query detail event.'];
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc() ?: null;
        $stmt->close();
        return [$row, ''];
    };

    // Prioritas: id road_run -> id triathlons -> id trail_run -> nama road_run -> nama triathlons -> nama trail_run
    if ($eventId !== null) {
        [$event, $err] = $fetchById('road_run', $eventId);
        $eventSource = $event ? 'road_run' : null;
        if (!$event && $err) { $dbError = $err; }

        if (!$event) {
            [$event, $err] = $fetchById('triathlons', $eventId);
            $eventSource = $event ? 'triathlons' : null;
            if (!$event && $err) { $dbError = $err; }
        }

        if (!$event) {
            [$event, $err] = $fetchById('trail_run', $eventId);
            $eventSource = $event ? 'trail_run' : null;
            if (!$event && $err) { $dbError = $err; }
        }
    }

    if (!$event && $eventNameParam) {
        [$event, $err] = $fetchByName('road_run', $eventNameParam);
        $eventSource = $event ? 'road_run' : null;
        if (!$event && $err) { $dbError = $err; }

        if (!$event) {
            [$event, $err] = $fetchByName('triathlons', $eventNameParam);
            $eventSource = $event ? 'triathlons' : null;
            if (!$event && $err) { $dbError = $err; }
        }

        if (!$event) {
            [$event, $err] = $fetchByName('trail_run', $eventNameParam);
            $eventSource = $event ? 'trail_run' : null;
            if (!$event && $err) { $dbError = $err; }
        }
    }

    $conn->close();
} else {
    $dbError = 'Koneksi database gagal.';
}

// Fallback: jika DB kosong atau tidak ditemukan, arahkan kembali
if (!$event) {
    header("Location: index.php");
    exit;
}

// Normalisasi field dengan fallback agar aman terhadap nama kolom berbeda
$eventNormalized = [
    'title' => $event['event_name'] ?? ($event['title'] ?? ($event['name'] ?? 'Event')),
    'date' => $event['event_date'] ?? ($event['date'] ?? '-'),
    'location' => $event['location'] ?? ($event['event_location'] ?? '-'),
    'distance' => $event['distance'] ?? ($event['category'] ?? '-'),
    'category' => $eventSource === 'road_run'
        ? 'Road Run'
        : ($eventSource === 'triathlons'
            ? 'Triathlon'
            : ($eventSource === 'trail_run'
                ? 'Trail Run'
                : ($event['event_type'] ?? ($event['type'] ?? '-')))),
    'description' => $event['description'] ?? '-',
    // Ambil fee dari kolom registration_fee bila ada, fallback ke price
    'price' => $event['registration_fee'] ?? ($event['price'] ?? '-'),
    'time' => $event['time'] ?? '-',
    'quota' => $event['quota'] ?? '-',
    'contact' => $event['contact'] ?? '-',
];

$pageTitle = $eventNormalized['title'] . ' - Detail';
$isLoggedIn = isset($_SESSION['user_id']);
?>
<!doctype html>
<html lang="id">
<?php include __DIR__ . '/includes/head.php'; ?>
<body class="home-page">
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="event-detail-main">
    <div class="event-detail-container">
        <div class="event-detail-header">
            <h1><?= htmlspecialchars($eventNormalized['title']) ?></h1>
            <p class="event-category">Kategori: <?= htmlspecialchars($eventNormalized['category']) ?></p>
        </div>

        <?php if ($dbError): ?>
            <div class="error-message" style="margin:16px 0; color:#b00020; background:#fde6e8; padding:12px 16px; border-radius:8px;">
                <?= htmlspecialchars($dbError) ?>
            </div>
        <?php endif; ?>

        <div class="event-detail-content">
            <section class="event-detail-info">
                <h2>Informasi Event</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <strong>📅 Tanggal</strong>
                        <p><?= htmlspecialchars($eventNormalized['date']) ?></p>
                    </div>
                    <div class="info-item">
                        <strong>🕐 Waktu</strong>
                        <p><?= htmlspecialchars($eventNormalized['time']) ?></p>
                    </div>
                    <div class="info-item">
                        <strong>📍 Lokasi</strong>
                        <p><?= htmlspecialchars($eventNormalized['location']) ?></p>
                    </div>
                    <div class="info-item">
                        <strong>👟 Jarak</strong>
                        <p><?= htmlspecialchars($eventNormalized['distance']) ?></p>
                    </div>
                    <div class="info-item">
                        <strong>💰 Harga</strong>
                        <p><?= htmlspecialchars($eventNormalized['price']) ?></p>
                    </div>
                    <div class="info-item">
                        <strong>👥 Kuota</strong>
                        <p><?= htmlspecialchars($eventNormalized['quota']) ?></p>
                    </div>
                </div>
            </section>

            <section class="event-detail-description">
                <h2>Deskripsi</h2>
                <p><?= htmlspecialchars($eventNormalized['description']) ?></p>
            </section>

            <section class="event-detail-contact">
                <h2>Hubungi Panitia</h2>
                <p>☎️ <?= htmlspecialchars($eventNormalized['contact']) ?></p>
            </section>

            <section class="event-detail-actions">
                <?php if ($isLoggedIn): ?>
                    <button class="btn-register btn" onclick="alert('Berhasil mendaftar event!')">Daftar Event</button>
                <?php else: ?>
                    <a href="login.php" class="btn-register btn">Login untuk Mendaftar</a>
                <?php endif; ?>
                <a href="javascript:history.back()" class="btn-secondary btn">Kembali</a>
            </section>
        </div>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
<?php include __DIR__ . '/includes/footer-scripts.php'; ?>
</body>
</html>